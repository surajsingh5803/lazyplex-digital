<?php
/*
Plugin Name: Lazy Plex Elementor One-Time Refresh
Description: Temporary targeted Elementor cache refresh for the Growth Audit page.
Version: 1.0.0
*/
if (!defined('ABSPATH')) { exit; }
function lp_elementor_targeted_refresh_20261123() {
    if (get_option('lp_ele_refresh_20261123_done') === 'yes') { return; }
    delete_post_meta(46, '_elementor_element_cache');
    clean_post_cache(46);
    if (class_exists('\\Elementor\\Plugin')) {
        $plugin = \Elementor\Plugin::$instance;
        if (isset($plugin->files_manager) && method_exists($plugin->files_manager, 'clear_cache')) {
            $plugin->files_manager->clear_cache();
        }
    }
    update_option('lp_ele_refresh_20261123_done', 'yes', false);
}
add_action('init', 'lp_elementor_targeted_refresh_20261123', 999);
